def main():
    print("Hello world!")

__version__ = "0.0.12"
